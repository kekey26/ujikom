<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Peminjaman - Petugas Lab</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">

    <nav class="navbar navbar-expand-lg navbar-dark bg-success mb-4">
        <div class="container">
            <a class="navbar-brand" href="#">Panel Petugas Lab</a>
            <form action="<?php echo e(route('logout')); ?>" method="POST" class="d-inline">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-outline-light btn-sm">Logout</button>
            </form>
        </div>
    </nav>

    <div class="container">
        <?php if(session('success')): ?>
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>
        <?php if(session('error')): ?>
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
        <?php endif; ?>

        <h3 class="mb-3">Daftar Pengajuan & Transaksi Peminjaman</h3>

        <div class="card shadow-sm">
            <div class="card-body">
                <table class="table table-striped align-middle">
                    <thead>
                        <tr>
                            <th>Peminjam</th>
                            <th>Tanggal Pinjam</th>
                            <th>Rencana Kembali</th>
                            <th>Status</th>
                            <th>Alat yang Dipinjam</th>
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $peminjamans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($item->user->name ?? '-'); ?></td>
                                <td><?php echo e($item->tgl_pinjam); ?></td>
                                <td><?php echo e($item->tgl_kembali_plan); ?></td>
                                <td>
                                    <span class="badge
                                        <?php if($item->status == 'diajukan'): ?> bg-warning text-dark
                                        <?php elseif($item->status == 'dipinjam'): ?> bg-primary
                                        <?php elseif($item->status == 'selesai'): ?> bg-success
                                        <?php else: ?> bg-danger <?php endif; ?>">
                                        <?php echo e(ucfirst($item->status)); ?>

                                    </span>
                                </td>
                                <td>
                                    <ul class="mb-0 ps-3">
                                        <?php $__currentLoopData = $item->detailPinjams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($detail->alat->nama_alat ?? 'Alat'); ?> (<?php echo e($detail->jumlah); ?> pcs)</li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </td>
                                <td>
                                    <?php if($item->status == 'diajukan'): ?>
                                        <form action="<?php echo e(route('petugas.peminjaman.setujui', $item->id)); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-sm btn-success">Setujui</button>
                                        </form>
                                    <?php elseif($item->status == 'dipinjam'): ?>
                                        <!-- Form Sederhana Proses Pengembalian -->
                                        <form action="<?php echo e(route('petugas.pengembalian.proses', $item->id)); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <input type="hidden" name="kondisi_kembali" value="Baik">
                                            <input type="hidden" name="denda" value="0">
                                            <button type="submit" class="btn btn-sm btn-warning" onclick="return confirm('Proses pengembalian alat ini?')">
                                                Terima Kembali
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <span class="text-muted small">Selesai</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center">Belum ada data peminjaman.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</body>
</html><?php /**PATH /var/www/resources/views/petugas/peminjaman/index.blade.php ENDPATH**/ ?>